# fullMeanFriendsHalfway

Bower install, npm install!
