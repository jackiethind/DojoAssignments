

app.controller('editController',['$scope', '$routeParams', function ($scope, $routeParams) {
    console.log("editController loaded");
    console.log("$routeParams currently look like this: ", $routeParams);
}]);
