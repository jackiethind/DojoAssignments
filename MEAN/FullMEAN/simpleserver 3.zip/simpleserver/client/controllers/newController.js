

app.controller('newController', ['$scope', function($scope) {
    console.log("newController loaded");
    $scope.newFriend = {};
    $scope.create = function () {
        console.log("create friend clicked");
        console.log($scope.newFriend);
        console.log("I haven't sent this information to the server yet.");
    }
}]);
