var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var mongoose = require('mongoose');
app.use(bodyParser.urlencoded({extended:true}));
var path = require('path');
app.use(express.static(path.join(__dirname, './static')));
app.set('views',path.join(__dirname,'./views'));
app.set('view engine', 'ejs');
app.get('/', function (req,res) {
    res.render('index');
})
app.get('/showQuotes', function(req, res) {
    Quote.find({}, function(err,quotes){
        console.log(quotes);
        if(err){
            console.log("Something went wrong!");
        }
        else {
            console.log("Successfully got to results");
            res.render('results', {quotes:quotes});
        }
    })
})

app.post('/quotes', function(req,res) {
    console.log("POST DATA", req.body);
        var quote = new Quote({name:req.body.name, quote: req.body.quote});
        quote.save(function (err) {
            if(err){
                console.log("Something went wrong!");
                res.render('index', {title: 'you have errors!', errors: quote.errors})
            }
            else {
                console.log("Successfully added a quote");
                res.redirect('/showQuotes');
            }
        })
})

app.listen(8000, function () {
    console.log("listening on port 8000");
})


// MONGOOSE STUFF
mongoose.connect('mongodb://localhost/quotes_db');

mongoose.Promise = global.Promise;

var quoteSchema = new mongoose.Schema({
    name: {type: String,required:true, minLength:6},
    quote: {type: String, required:true, minLength:10},

}, {timestamps:true})
mongoose.model("Quote", quoteSchema);
var Quote = mongoose.model('Quote')
