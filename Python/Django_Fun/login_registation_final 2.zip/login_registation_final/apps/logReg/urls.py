from django.conf.urls import url, include
from . import views
urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$', views.register),
    url(r'^home$', views.home, name='trips_home'),
    url(r'^log_in$', views.log_in),
    url(r'^log_out$', views.log_out),
    url(r'^trip$', views.trip),
    url(r'^trip_process$', views.trip_process),
    url(r'^trip/(?P<id>\d+)$', views.join_trip),
    url(r'^tripinfo/(?P<id>\d+)$', views.trip_info),
    url(r'^remove/(?P<id>\d+)$', views.remove_trip),
    url(r'^.*$', views.error),


]
