from django.shortcuts import render, redirect, HttpResponse
from .models import User, Umanager, Trip, tripManager
from django.core.urlresolvers import reverse
from django.contrib import messages
# Create your views here.
def index(request):
    if 'id' in request.session:
        print id
        return redirect('/home')
    context = {
        'users': User.objects.all(),
    }
    return render(request, 'logReg/index.html', context)

def register(request):
    # ******* checks to see if request is get **********
    if request.method == 'GET':
        print "** Registration is POST-only **"
        return redirect('/')
    print " **** Registration Commencing ****"
    if request.method == "POST":
        # ******* begins registration function though user object **********
        user_check = User.objects.reg(request.POST)
        # ******* if status is returned, and valid is true **********
        if user_check['valid']:
            print "** Registration info is valid **"
            if 'id' not in request.session:
                # ******* get id of user from db by filter the user entered email **********
                new_user = User.objects.filter(email=request.POST['email'])[0]
                # ******** add id of the user who just registered to session *********
                print new_user.id
                request.session['id'] = new_user.id
                print
                return redirect('/home')
        # ******* else status is returned, and valid is false **********
        else:
            print "** Errors were found in "
            print user_check['messages']
            # ********* grab messages(object) from status (user_check) and store it in a var ***********
            user_messages = user_check['messages']
            # ********* iterate through messages object and flash error messages 1 by 1 ***********
            for i in user_messages:
                messages.add_message(request, messages.INFO, i )
            return redirect('/')

def log_in(request):
    # ******* checks to see if request is get **********
    if request.method == 'GET':
        print "** Login is POST-only **"
        return redirect('/')
    print "** Log in requested **"
    if request.method == "POST":
        # ******* begins login function though user object **********
        login_info = User.objects.log(request.POST)
        if login_info['valid']:
            # ******* if status is returned, and valid is true **********
            print "** Login info is valid **"
            if 'id' not in request.session:
                # ******* get id of user from db by filter the user entered email **********
                new_user = User.objects.filter(email=request.POST['elogin'])[0]
                # ******** add id of the user who just registered to session *********
                request.session['id'] = new_user.id
                return redirect('/home')
        # ******* else status is returned, and valid is false **********
        else:
            print "** Errors were found in "
            print login_info['messages']
            # ********* grab messages(object) from status (login_info) and store it in a var ***********
            user_messages = login_info['messages']
            # ********* iterate through messages object and flash error messages 1 by 1 ***********
            for i in user_messages:
                messages.add_message(request, messages.INFO, i )
            return redirect('/')
def trip_process(request):
        # ******* checks to see if request is get **********
        if request.method == 'GET':
            print "** Trip process is POST-only **"
            return redirect('/')
        print "** Trip Maker requested **"
        if request.method == "POST":
            # ******* begins login function though user object **********
            user_id = request.session['id']
            trip_info = Trip.objects.tripValidate( user_id, request.POST)
            if trip_info['valid']:
                # ******* if status is returned, and valid is true **********
                print "** Trip info is valid **"
            # ******* else status is returned, and valid is false **********
            else:
                print "** Errors were found in "
                print trip_info['messages']
                # ********* grab messages(object) from status (login_info) and store it in a var ***********
                user_messages = trip_info['messages']
                # ********* iterate through messages object and flash error messages 1 by 1 ***********
                for i in user_messages:
                    messages.add_message(request, messages.INFO, i )
            return redirect(reverse('trips_home'))
def trip(request):
        # ********* makes sure user cannot input /home on browser ***********
        if 'id' not in request.session:
            print "USER TRIED TO GO TO TRIP***************"
            messages.add_message(request, messages.INFO, "You must be logged in!" )
            return redirect('/')
        else:
            # ********* if user is logged in however, render home page when they input /home on browser ***********
            context = {
                'users': User.objects.get(id=request.session['id'])
            }
            print context['users']
            return render(request, 'logReg/addtrip.html', context)
def join_trip(request,id):
            # ********* makes sure user cannot input /home on browser ***********
        if 'id' not in request.session:
            print "USER TRIED TO GO TO TRIP***************"
            messages.add_message(request, messages.INFO, "You must be logged in!" )
            return redirect('/')
        # if request.method == 'GET':
        #     print "** Trip process is POST-only **"
        #     return redirect('/')
        print "** Trip Joiner requested **"
        user_id = request.session['id']
        trip_id = id
        trip_add = Trip.objects.joinTrips(user_id, trip_id)
        if not trip_add['valid']:
            print "** Error in joining trip "
            print trip_add['messages']
            for i in user_messages:
                messages.add_message(request, messages.INFO, i )
        return redirect('/')

def home(request):
    # ********* makes sure user cannot input /home on browser ***********
    if 'id' not in request.session:
        print "USER TRIED TO GO HOME***************"
        messages.add_message(request, messages.INFO, "You must be logged in!" )
        return redirect('/')
    else:
        # ********* if user is logged in however, render home page when they input /home on browser ***********
        print "** Welcome back, user! **"

        context = {
            'users': User.objects.get(id=request.session['id']),
            'alltrips': Trip.objects.all().exclude(user__id=request.session['id']).order_by('-tdfrom')[0:5],
            'usertrips': Trip.objects.filter(user__id=request.session['id']).order_by('-tdfrom')[0:5],

        }
        print context['users'].id
        return render(request, 'logReg/home.html', context)
def trip_info(request,id):
    # ********* makes sure user cannot input /home on browser ***********
    if 'id' not in request.session:
        print "USER TRIED TO GO HOME***************"
        messages.add_message(request, messages.INFO, "You must be logged in!" )
        return redirect('/')
    else:
        # ********* if user is logged in however, render home page when they input /home on browser ***********
        print "** Welcome back, user! **"
        user_id = request.session['id']
        trip_id = id
        context = {
            'users': User.objects.get(id=request.session['id']),
            'users_this_trip': User.objects.filter(trips__id=trip_id).exclude(id=request.session['id']),
            'this_trip': Trip.objects.filter(id=trip_id),
            'usertrips': Trip.objects.filter(user__id=request.session['id']).order_by('-tdfrom')[0:5],

        }
        print context['users_this_trip']
        return render(request, 'logReg/tripinfo.html', context)
def remove_trip(request,id):
    # ********* makes sure user cannot input /home on browser ***********
    if 'id' not in request.session:
        print "USER TRIED TO GO HOME***************"
        messages.add_message(request, messages.INFO, "You must be logged in!" )
        return redirect('/')
    Trip.objects.filter(id=id).delete()
    # else:
    #     # ********* if user is logged in however, render home page when they input /home on browser ***********
    #     print "** Welcome back, user! **"
    #     user_id = request.session['id']
    #     trip_id = id
    #     context = {
    #         'users': User.objects.get(id=request.session['id']),
    #         'users_this_trip': User.objects.filter(trips__id=trip_id).exclude(id=request.session['id']),
    #         'this_trip': Trip.objects.filter(id=trip_id),
    #         'usertrips': Trip.objects.filter(user__id=request.session['id']).order_by('-tdfrom')[0:5],
    #
    #     }
    #     print context['users_this_trip']
    return redirect('/')
# def trip_about(request,id):
#         if 'id' not in request.session:
#             print "USER TRIED TO GO TO TRIP***************"
#             messages.add_message(request, messages.INFO, "You must be logged in!" )
#             return redirect('/')
#         # if request.method == 'GET':
#         #     print "** Trip process is POST-only **"
#         #     return redirect('/')
#         print "** Trip Joiner requested **"
#         user_id = request.session['id']
#         trip_id = id
#         trip_add = Trip.objects.joinTrips(user_id, trip_id)
#         if not trip_add['valid']:
#             print "** Error in joining trip "
#             print trip_add['messages']
#             for i in user_messages:
#                 messages.add_message(request, messages.INFO, i )
#         return redirect('/trip_info')

def log_out(request):
    # ********* clears session, logs user out ***********
    request.session.flush()
    return redirect('/')

def error(request):
    print "USER TRIED TO GO Enter bad request ***************"
    messages.add_message(request, messages.INFO, "Page Does Not Exist!" )
    return redirect('/')
