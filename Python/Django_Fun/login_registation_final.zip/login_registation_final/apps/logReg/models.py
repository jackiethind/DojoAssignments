from __future__ import unicode_literals
from django.db import models
import re, bcrypt, time

EMAIL_REGEX = re.compile(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)")
PASSWORD_REGEX = re.compile(r'((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,})', re.MULTILINE)
name_regex = re.compile(r'[a-zA-Z]+', re.MULTILINE)

# Create your models here.
class Umanager(models.Manager):
    def reg(self, postData):
        # ************ TAKES postData as a dictionary  **************
        print "**** Umanager active ****"
        print "**** Checking registration form ****"
        # *************** status is going to be returned at the end ****************
        status = {}
        # ************ Messages are going to appended to this array  **************
        messages = []
        # ************ Collect all user post data **************
        first = postData['first']
        last = postData['last']
        email = postData['email']
        password = postData['password']
        confirm = postData['confirm']
        birthday = postData['birthday']
        print first, last, email, confirm, birthday
        # ************ Validate all User input for registration **************
        if len(first) < 2 or len(last) < 2:
            messages.append("Name fields cannot be blank and must be longer than 2 characters.")
        if not name_regex.match(first) or not name_regex.match(last):
            messages.append("Name fields can only contain letters from the English Alphabet")
        if len(email) < 1:
            messages.append("Email field cannot be blank.")
        elif len(User.objects.filter(email=email)) > 0:
            # if list of users w/ this email is empty
            messages.append("Email address is already registered.")
        elif not EMAIL_REGEX.match(email):
            messages.append("Invalid email format.")
        if len(password) < 1:
            messages.append('Password is required.')
        elif len(password) < 8:
            messages.append('Password should be at least 8 characters.')
        elif not PASSWORD_REGEX.match(password):
            messages.append("Password must have at least 1 Upper Case letter, 1 Lower Case letter, and 1 number.")
        elif not password == confirm:
            messages.append('Password fields do not match.')
        if not re.search(r'^[0-9][0-9][0-9][0-9][\-][0-9][0-9][\-][0-9][0-9]', birthday):
            messages.append('Invalid birthday format. Should be YYYY-MM-DD format.')
        elif birthday > time.strftime("%Y-%m-%d"):
            messages.append('Invalid birthday! Need to be from the past.')
        # ************ if there is something in messages, then messages is true **************
        # ******** this is saying if there are no error messages, then the input will be valid ************
        if not messages:
            valid = True
            messages.append('Thank you for registering! Please sign in.')
            # ************** converts users password to hash ***************
            pwhash = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
            # *************** creates a new user object ******************
            User.objects.create(first=first, last=last, email=email, password=pwhash, birthday=birthday)
        # ********* if there are error messages **************
        else:
            valid = False
        # *************** valid is a boolean and messages is a dictionary ******************
        status.update({'valid': valid, 'messages': messages})

        return status


    def log(self, postData):
        print "** Umanager activated **"
        print "** Checking login info **"
        # *************** status is going to be returned at the end ****************
        status = {}
        # ************ Messages are going to appended to this array  **************
        messages = []
        # ************ Collect all user post data **************
        email = postData['elogin']
        password = postData['plogin']
        print email, password
        # ************ Validate all User input for registration **************
        if len(email) < 1 or len(password) < 1:
            messages.append("Login fields cannot be blank.")
        else:
            # ********* trys to find email in database **************
            validEmail = User.objects.filter(email=email)
            if not validEmail:
                messages.append("Unable to find user. Please register.")
            # ********* tries to match user entered pw with pw in database **************
            elif not bcrypt.checkpw(password.encode(), validEmail[0].password.encode()):
                messages.append("Incorrect password.")
        # ************ if there is something in messages, then messages is true **************
        # ******** this is saying if there are no error messages, then the input will be valid/true ************
        if not messages:
            valid = True
            # ************** this will update status with the entered valid email and get user from db ******
            status.update({'user_id': validEmail[0].id})
        else:
            valid = False
            # ********* this will update all the error messages as objects in the messages key ************
            status.update({'messages': messages})
        status.update({'valid': valid})
        return status



class User(models.Model):
    first = models.CharField(max_length=45)
    last = models.CharField(max_length=45)
    email = models.EmailField(max_length=45, unique = True)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    birthday = models.DateField(auto_now = False, auto_now_add = False, default="9999-11-29")
    objects = Umanager()
