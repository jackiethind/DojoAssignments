from django.shortcuts import render, redirect, HttpResponse
from .models import User, Umanager
from django.contrib import messages
# Create your views here.
def index(request):
    if 'id' in request.session:
        return redirect('/home')
    # context = {
    #     'users': User.objects.all(),
    # }
    return render(request, 'logReg/index.html')

def register(request):
    # ******* checks to see if request is get **********
    if request.method == 'GET':
        print "** Registration is POST-only **"
        return redirect('/')
    print " **** Registration Commencing ****"
    if request.method == "POST":
        # ******* begins registration function though user object **********
        user_check = User.objects.reg(request.POST)
        # ******* if status is returned, and valid is true **********
        if user_check['valid']:
            print "** Registration info is valid **"
            if 'id' not in request.session:
                # ******* get id of user from db by filter the user entered email **********
                new_user = User.objects.filter(email=request.POST['email'])[0]
                # ******** add id of the user who just registered to session *********
                request.session['id'] = new_user.id
                return redirect('/home')
        # ******* else status is returned, and valid is false **********
        else:
            print "** Errors were found in "
            print user_check['messages']
            # ********* grab messages(object) from status (user_check) and store it in a var ***********
            user_messages = user_check['messages']
            # ********* iterate through messages object and flash error messages 1 by 1 ***********
            for i in user_messages:
                messages.add_message(request, messages.INFO, i )
            return redirect('/')

def log_in(request):
    # ******* checks to see if request is get **********
    if request.method == 'GET':
        print "** Login is POST-only **"
        return redirect('/')
    print "** Log in requested **"
    if request.method == "POST":
        # ******* begins login function though user object **********
        login_info = User.objects.log(request.POST)
        if login_info['valid']:
            # ******* if status is returned, and valid is true **********
            print "** Login info is valid **"
            if 'id' not in request.session:
                # ******* get id of user from db by filter the user entered email **********
                new_user = User.objects.filter(email=request.POST['elogin'])[0]
                # ******** add id of the user who just registered to session *********
                request.session['id'] = new_user.id
                return redirect('/home')
        # ******* else status is returned, and valid is false **********
        else:
            print "** Errors were found in "
            print login_info['messages']
            # ********* grab messages(object) from status (login_info) and store it in a var ***********
            user_messages = login_info['messages']
            # ********* iterate through messages object and flash error messages 1 by 1 ***********
            for i in user_messages:
                messages.add_message(request, messages.INFO, i )
            return redirect('/')


def home(request):
    # ********* makes sure user cannot input /home on browser ***********
    if 'id' not in request.session:
        print "USER TRIED TO GO HOME***************"
        messages.add_message(request, messages.INFO, "You must be logged in!" )
        return redirect('/')
    else:
        # ********* if user is logged in however, render home page when they input /home on browser ***********
        context = {
            'users': User.objects.get(id=request.session['id'])
        }
        return render(request, 'logReg/home.html', context)
def log_out(request):
    # ********* clears session, logs user out ***********
    request.session.flush()
    return redirect('/')

def error(request):
    print "USER TRIED TO GO Enter bad request ***************"
    messages.add_message(request, messages.INFO, "Page Does Not Exist!" )
    return redirect('/')
