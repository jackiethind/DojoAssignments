from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count
from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"baseball_leagues":League.objects.filter(sport="Baseball"),
		"womens_leagues":League.objects.filter(name__contains="Women"),
		"hockey_leagues":League.objects.filter(name__contains="Hockey"),
		"allbutfootball":League.objects.exclude(name__contains="Football"),
		"conferences":League.objects.filter(name__contains="Conference"),
		"atlantic":League.objects.filter(name__contains="Atlantic"),
		"dallas":Team.objects.filter(location="Dallas"),
		"raptors":Team.objects.filter(team_name__contains="Raptors"),
		"city":Team.objects.filter(location__contains="City"),
		"T":Team.objects.filter(team_name__startswith="T"),
		"alpha":Team.objects.order_by('location'),
		"reverse":Team.objects.order_by('team_name').reverse(),
		"teams":Team.objects.all(),
		"players": Player.objects.all(),
		"cooper":Player.objects.filter(last_name="Cooper"),
		"joshua":Player.objects.filter(first_name="Joshua"),
		"notjoshua":Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua"),
		"alexandwyatt":Player.objects.filter(first_name="Alexander")| Player.objects.filter(first_name="Wyatt"),
		"atlanticsoccer":Team.objects.filter(league=League.objects.filter(name__icontains="Atlantic", sport__icontains="soccer")),
		"penguins":Player.objects.filter(curr_team=Team.objects.filter(team_name__icontains="penguins", location__icontains="Boston")),
		"baseball":Player.objects.filter(curr_team__league__name__icontains="collegiate"),
		"lopez":Player.objects.filter(curr_team__league__name__icontains="Amateur Football", last_name = "Lopez"),
		"football":Player.objects.filter(curr_team__league__sport__icontains="football"),
		"sophia": Team.objects.filter(curr_players__first_name__icontains="Sophia"),
		"sophia2": League.objects.filter(teams__curr_players__first_name__icontains="Sophia"),
		"flores": Player.objects.filter(last_name="Flores").exclude(curr_team__team_name__icontains="Roughriders"),
		"sam": Team.objects.filter(all_players__first_name__icontains= "Samuel").filter(all_players__last_name__icontains="Evans"),
		"tigercats":Player.objects.filter(all_teams__team_name__icontains="Tiger-Cats").filter(all_teams__location__icontains="Manitoba"),
		"vikings":Player.objects.filter(all_teams__team_name__icontains="Vikings").exclude(curr_team__team_name__icontains="Vikings"),
		"jacobgray":Team.objects.filter(all_players__first_name__icontains="Jacob").filter(all_players__last_name__icontains="Gray").exclude(curr_players__first_name__icontains="Jacob").exclude(curr_players__last_name__icontains="Gray"),
		"joshua":Player.objects.filter(all_teams__league__name="Atlantic Federation of Amateur Baseball Players").filter(first_name="Joshua"),
		"twelve":Team.objects.annotate(num_players=Count('all_players')).filter(num_players__gte=12),
		"teamnum":Player.objects.annotate(num_teams=Count("all_teams")).reverse(),
		# "baseball":Player.objects.filter(curr_team=Team.objects.filter(league=League.objects.filter(sport="Baseball"))),
	}
	print context['sophia']
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
