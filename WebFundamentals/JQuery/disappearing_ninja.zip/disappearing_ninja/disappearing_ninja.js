$(document).ready(function(){
    $('html,body').css('cursor','crosshair');
            $('#resurrect').click(function () {
                $('.blocks_1').fadeIn("slow", function() {
                    console.log( "Jon is Back!" );
                    })
            });
            $('#jon_1').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!" );
                    })
            });
            $('#jon_2').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!." );
                    })
            });
            $('#jon_3').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!." );
                    })
            });
            $('#jon_4').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!." );
                    })
            });
            $('#jon_5').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!." );
                    })
            });
            $('#jon_6').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!." );
                    })
            });
            $('#jon_7').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!." );
                    })
            });
            $('#jon_8').click(function () {
                $(this).fadeOut("slow", function() {
                    console.log( "Jon Died!." );
                    })
            });
        });
