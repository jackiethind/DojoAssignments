//
//  ViewController.swift
//  Beast List
//
//  Created by Jackie Thind on 3/14/17.
//
//

import UIKit

class ViewController: UIViewController {
    
    var tasks = ["something cool", "Something VERY cool", "something EXTREMELY cool"]
    @IBOutlet weak var taskTextField: UITextField!

    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func beastButtonPressed(_ sender: UIButton) {
        // your code here
        // Add the textField text as an item to the array
        tasks.append(taskTextField.text!)
        // reload the table view data
        tableView.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

// Controller conforms to the UITableViewDataSource protocol:
extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        cell.textLabel?.text = tasks[indexPath.row]
        return cell
    }
}

