//
//  WordEntryViewController.swift
//  MadLibs
//
//  Created by Jackie Thind on 3/15/17.
//  Copyright © 2017 Jackie Thind. All rights reserved.
//

import UIKit

class WordEntryViewController: UIViewController {

    @IBOutlet weak var adjectiveTextLabel: UITextField!
    @IBOutlet weak var verb1TextLabel: UITextField!
    @IBOutlet weak var verb2TextLabel: UITextField!
    @IBOutlet weak var nounTextLabel: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    
}
